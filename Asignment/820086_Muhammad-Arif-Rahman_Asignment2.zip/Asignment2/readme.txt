Nama		: Muhammad Arif Rahman
No. Peserta	: 820086
Kode Peserta: FSDO003ONL004
link github : https://github.com/ApeloezA/ocbc-batch-3.git


panduan penggunaan aplikasi:
	buat database dengan nama "db_bank"
	lalu import db_bank.sql	

link github : https://github.com/ApeloezA/ocbc-batch-3.git

untuk catatan saya akan berkerja keras untuk tugas inputan 

terima kasih