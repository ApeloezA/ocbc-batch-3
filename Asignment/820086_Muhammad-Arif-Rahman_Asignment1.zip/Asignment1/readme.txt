Nama		: Muhammad Arif Rahman
No. Peserta	: 820086
Kode Peserta: FSDO003ONL004
link github : https://github.com/ApeloezA/ocbc-batch-3.git


panduan penggunaan aplikasi:
	setiap soal dibuat dalam satu file contoh file soal1
	dan untuk file soal1 dan soal2 memiliki file coba2
	
untuk run soal1
	cd Asignment1\soal1
	mcs piramidaHuruf.cs -out:piramidaHuruf && nano piramidaHuruf

	cd coba2-1
	mcs coba2.cs -out:coba2 && nano coba2

	cd .. 
	cd coba2-2
	mcs coba2.cs -out:coba2 && nano coba2

untuk run soal2
	cd Asignment1\soal2
	mcs piramidaAngka.cs -out:piramidaAngka && nano piramidaAngka

	cd .. 
	cd coba2
	mcs coba2.cs -out:coba2 && nano coba2

untuk run soal3
	cd Asignment1\soal3
	mcs faktorial.cs -out:faktorial && nano faktorial

untuk run soal4
	cd Asignment1\soal4
	mcs flipNumber.cs -out:flipNumber && nano flipNumber

untuk run soal5
	cd Asignment1\soal5
	mcs numberToWord.cs -out:numberToWord && nano numberToWord
	

link github : https://github.com/ApeloezA/ocbc-batch-3.git


untuk catatan saya akan berkerja keras untuk tugas inputan 

terima kasih